<?php
$db = mysql_connect("localhost", "root", "") or die("Erro de conex�o com o banco: " . mysql_error());
mysql_select_db ("sbes");
?>