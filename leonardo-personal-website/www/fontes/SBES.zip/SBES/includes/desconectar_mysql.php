<? //Desconecta do banco.
mysql_close($db); 
?>