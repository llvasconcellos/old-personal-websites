<?
require("funcoes.php");
require("conectar_mysql.php");
?>
<html>
	<head>
		<title>Impress�o de Capas</title>
		<style type="text/css">
		td {
			text-align: left;
			vertical-align: top;
			font-size: <?=$fonte?>;
			font-family:Arial, Helvetica, sans-serif;
			page-break-inside: avoid;
		}
		</style>
	</head>
	<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
		<table width="100%" cellspacing="5" cellpadding="5" border="0">
		<tr>
		<?
		require("conectar_mysql.php");		
		$query = "SELECT * FROM titulos WHERE id_tipo_media = " . $id_tipo_media . " ORDER BY nome_titulo";
		$result = mysql_query($query) or tela_erro("Erro de conex�o ao banco de dados: " . mysql_error(), false);
		$j = 0; 
		$i = 1;
		while ($vcd = mysql_fetch_assoc($result)) { 
		?>
			<td>
				<img border="0" src="imagem_dinamica.php?largura_limite=<?=$largura?>&id_titulo=<?=$vcd["id_titulo"]?>">
				<br>
				<?=$vcd["id_titulo"]?>&nbsp;-&nbsp;<?=$vcd["nome_titulo"]?><br>
			</td>
		<?
			$j++;
			if ($j == $linha){
				if($i == $linha_pagina){
					echo('</tr><tr style="page-break-before: always;">');
					$i = 1;
				}
				else{
					echo("</tr><tr>");
					$i++;
				}
				$j = 0;
				
			}
		}
		?>
		</tr>
	</table>
		<? require("desconectar_mysql.php"); ?>
	</body>
</html>
