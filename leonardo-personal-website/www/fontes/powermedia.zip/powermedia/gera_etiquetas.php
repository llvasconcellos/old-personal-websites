<?
require("funcoes.php");
require("conectar_mysql.php");
?>
<html>
	<head>
		<title>Impress�o de Etiquetas</title>
		<style type="text/css">
		td {
			text-align: center;
			vertical-align: middle;
			font-size: <?=$fonte?>;
			font-family:Arial, Helvetica, sans-serif;
			page-break-inside: avoid;
			width: <?=$largura?>;
			height: <?=$altura?>;
			<? if($borda == "on") echo('border: "solid 1px black";'); ?>
		}
		</style>
	</head>
	<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
		<table width="100%" cellspacing="<?=$espacamento_etiquetas?>">
		<tr>
		<?
		require("conectar_mysql.php");		
		$query = "SELECT * FROM titulos WHERE id_tipo_media = " . $id_tipo_media . " ORDER BY nome_titulo";
		$result = mysql_query($query) or tela_erro("Erro de conex�o ao banco de dados: " . mysql_error(), false);
		$j = 0; 
		$i = 1;
		for($count = 0; $count < $qtd_impressa; $count++){
			echo("<td>&nbsp;</td>");
			$j++;
			if ($j == $etiquetas_linha){
				if($i == $linhas_pagina_etiqueta){
					echo('</tr><tr style="page-break-before: always;">');
					$i = 1;
				}
				else{
					echo("</tr><tr>");
					$i++;
				}
				$j = 0;
				
			}
		}
		while ($vcd = mysql_fetch_assoc($result)) { 
		?>
			<td>
				<font color="#FF0000"><?=$vcd["id_titulo"]?></font>&nbsp;-&nbsp;<?=substr($vcd["nome_titulo"], 0, $limite_caracteres)?><br>
			</td>
		<?
			$j++;
			if ($j == $etiquetas_linha){
				if($i == $linhas_pagina_etiqueta){
					echo('</tr><tr style="page-break-before: always;">');
					$i = 1;
				}
				else{
					echo("</tr><tr>");
					$i++;
				}
				$j = 0;
				
			}
		}
		?>
		</tr>
	</table>
		<? require("desconectar_mysql.php"); ?>
	</body>
</html>
